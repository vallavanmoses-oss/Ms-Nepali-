package com.nepalichristiyabhajan.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.nepalichristiyabhajan.app.ui.SongbookViewModel
import com.nepalichristiyabhajan.app.ui.screens.HomeScreen
import com.nepalichristiyabhajan.app.ui.screens.LordsPrayerScreen
import com.nepalichristiyabhajan.app.ui.screens.SongDetailScreen
import com.nepalichristiyabhajan.app.ui.theme.NepaliChristiyaBhajanTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: SongbookViewModel = viewModel()
            val uiState by viewModel.uiState.collectAsState()
            val navController = rememberNavController()

            NepaliChristiyaBhajanTheme(darkTheme = uiState.isDarkMode) {
                NavHost(
                    navController = navController,
                    startDestination = "home"
                ) {
                    composable("home") {
                        HomeScreen(
                            uiState = uiState,
                            onSelectSection = viewModel::selectSection,
                            onSelectCategory = viewModel::selectCategory,
                            onSearchQueryChange = viewModel::updateSearchQuery,
                            onToggleFavorite = viewModel::toggleFavorite,
                            onToggleDarkMode = viewModel::toggleDarkMode,
                            onOpenSong = { songId -> navController.navigate("song/$songId") },
                            onOpenLordsPrayer = { navController.navigate("lords_prayer") }
                        )
                    }
                    composable(
                        route = "song/{songId}",
                        arguments = listOf(navArgument("songId") { type = NavType.StringType })
                    ) { backStackEntry ->
                        val songId = backStackEntry.arguments?.getString("songId") ?: ""
                        val song = viewModel.getSongById(songId)
                        val (prevId, nextId) = viewModel.getAdjacentSongIds(songId)
                        SongDetailScreen(
                            song = song,
                            categories = uiState.categories,
                            isFavorite = songId in uiState.favoriteIds,
                            fontSizeSp = uiState.fontSizeSp,
                            keepScreenOn = uiState.keepScreenOn,
                            prevSongId = prevId,
                            nextSongId = nextId,
                            onBack = { navController.popBackStack() },
                            onToggleFavorite = { viewModel.toggleFavorite(songId) },
                            onAdjustFontSize = viewModel::adjustFontSize,
                            onToggleKeepScreenOn = viewModel::toggleKeepScreenOn,
                            onNavigateToSong = { targetId ->
                                navController.navigate("song/$targetId") {
                                    popUpTo("song/$songId") { inclusive = true }
                                }
                            }
                        )
                    }
                    composable("lords_prayer") {
                        LordsPrayerScreen(
                            lordsPrayer = uiState.lordsPrayer,
                            fontSizeSp = uiState.fontSizeSp,
                            onBack = { navController.popBackStack() }
                        )
                    }
                }
            }
        }
    }
}
