package com.nepalichristiyabhajan.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = Color(0xFF6B2D38),          // Deep Crimson / Burgundy
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFFFD9DE),
    onPrimaryContainer = Color(0xFF3F0C18),
    secondary = Color(0xFF8C6239),        // Warm Gold / Amber
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFFFE0C2),
    onSecondaryContainer = Color(0xFF331D04),
    background = Color(0xFFFCF8F5),       // Warm Cream Paper
    onBackground = Color(0xFF1F1A1B),
    surface = Color(0xFFFCF8F5),
    onSurface = Color(0xFF1F1A1B),
    surfaceVariant = Color(0xFFF3E8E5),
    onSurfaceVariant = Color(0xFF524345)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFFFB2BC),
    onPrimary = Color(0xFF561D28),
    primaryContainer = Color(0xFF72333E),
    onPrimaryContainer = Color(0xFFFFD9DE),
    secondary = Color(0xFFE5C198),
    onSecondary = Color(0xFF422C10),
    secondaryContainer = Color(0xFF5B4223),
    onSecondaryContainer = Color(0xFFFFE0C2),
    background = Color(0xFF171213),
    onBackground = Color(0xFFEDE0E1),
    surface = Color(0xFF171213),
    onSurface = Color(0xFFEDE0E1),
    surfaceVariant = Color(0xFF2D2224),
    onSurfaceVariant = Color(0xFFD6C2C4)
)

@Composable
fun NepaliChristiyaBhajanTheme(
    darkTheme: Boolean,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        content = content
    )
}
