package com.nepalichristiyabhajan.app.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json

class SongRepository(private val context: Context) {

    private val json = Json {
        ignoreUnknownKeys = true
        isLenient = true
    }

    private var cachedData: SongbookData? = null

    suspend fun loadSongbook(): SongbookData = withContext(Dispatchers.IO) {
        cachedData?.let { return@withContext it }
        val raw = context.assets.open("songs.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
        val parsed = json.decodeFromString<SongbookData>(raw)
        cachedData = parsed
        parsed
    }
}
