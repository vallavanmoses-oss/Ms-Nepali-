package com.nepalichristiyabhajan.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nepalichristiyabhajan.app.data.LordsPrayer
import com.nepalichristiyabhajan.app.data.Song
import com.nepalichristiyabhajan.app.data.SongCategory
import com.nepalichristiyabhajan.app.data.SongRepository
import com.nepalichristiyabhajan.app.data.SongSection
import com.nepalichristiyabhajan.app.data.UserPreferencesRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class SongbookUiState(
    val isLoading: Boolean = true,
    val error: String? = null,
    val allSongs: List<Song> = emptyList(),
    val filteredSongs: List<Song> = emptyList(),
    val categories: List<SongCategory> = emptyList(),
    val lordsPrayer: LordsPrayer? = null,
    val selectedSection: SongSection = SongSection.BHAJAN,
    val selectedCategoryId: String? = null,
    val searchQuery: String = "",
    val favoriteIds: Set<String> = emptySet(),
    val fontSizeSp: Float = 19f,
    val isDarkMode: Boolean = false,
    val keepScreenOn: Boolean = true
)

class SongbookViewModel(application: Application) : AndroidViewModel(application) {

    private val songRepo = SongRepository(application)
    private val prefsRepo = UserPreferencesRepository(application)

    private val _allSongs = MutableStateFlow<List<Song>>(emptyList())
    private val _categories = MutableStateFlow<List<SongCategory>>(emptyList())
    private val _lordsPrayer = MutableStateFlow<LordsPrayer?>(null)
    private val _isLoading = MutableStateFlow(true)
    private val _error = MutableStateFlow<String?>(null)
    private val _selectedSection = MutableStateFlow(SongSection.BHAJAN)
    private val _selectedCategoryId = MutableStateFlow<String?>(null)
    private val _searchQuery = MutableStateFlow("")

    val uiState: StateFlow<SongbookUiState> = combine(
        _isLoading,
        _error,
        _allSongs,
        _categories,
        _lordsPrayer,
        _selectedSection,
        _selectedCategoryId,
        _searchQuery,
        prefsRepo.favoriteIds,
        prefsRepo.fontSizeSp,
        prefsRepo.isDarkMode,
        prefsRepo.keepScreenOn
    ) { values ->
        val isLoading = values[0] as Boolean
        val error = values[1] as String?
        @Suppress("UNCHECKED_CAST")
        val allSongs = values[2] as List<Song>
        @Suppress("UNCHECKED_CAST")
        val categories = values[3] as List<SongCategory>
        val lordsPrayer = values[4] as LordsPrayer?
        val section = values[5] as SongSection
        val categoryId = values[6] as String?
        val query = values[7] as String
        @Suppress("UNCHECKED_CAST")
        val favIds = values[8] as Set<String>
        val fontSize = values[9] as Float
        val darkMode = values[10] as Boolean
        val keepScreenOn = values[11] as Boolean

        val filtered = filterSongs(allSongs, section, categoryId, query, favIds)

        SongbookUiState(
            isLoading = isLoading,
            error = error,
            allSongs = allSongs,
            filteredSongs = filtered,
            categories = categories,
            lordsPrayer = lordsPrayer,
            selectedSection = section,
            selectedCategoryId = categoryId,
            searchQuery = query,
            favoriteIds = favIds,
            fontSizeSp = fontSize,
            isDarkMode = darkMode,
            keepScreenOn = keepScreenOn
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = SongbookUiState()
    )

    init {
        viewModelScope.launch {
            try {
                val data = songRepo.loadSongbook()
                _allSongs.value = data.songs
                _categories.value = data.categories
                _lordsPrayer.value = data.lordsPrayer
                _isLoading.value = false
            } catch (e: Exception) {
                _error.value = e.localizedMessage ?: "Failed to load songbook"
                _isLoading.value = false
            }
        }
    }

    fun selectSection(section: SongSection) {
        _selectedSection.value = section
        if (section != SongSection.BHAJAN) {
            _selectedCategoryId.value = null
        }
    }

    fun selectCategory(categoryId: String?) {
        _selectedCategoryId.value = categoryId
        if (categoryId != null) {
            _selectedSection.value = SongSection.BHAJAN
        }
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun toggleFavorite(songId: String) {
        viewModelScope.launch { prefsRepo.toggleFavorite(songId) }
    }

    fun adjustFontSize(delta: Float) {
        viewModelScope.launch {
            val current = uiState.value.fontSizeSp
            prefsRepo.setFontSize(current + delta)
        }
    }

    fun toggleDarkMode() {
        viewModelScope.launch { prefsRepo.setDarkMode(!uiState.value.isDarkMode) }
    }

    fun toggleKeepScreenOn() {
        viewModelScope.launch { prefsRepo.setKeepScreenOn(!uiState.value.keepScreenOn) }
    }

    fun getSongById(songId: String): Song? = _allSongs.value.find { it.id == songId }

    fun getAdjacentSongIds(songId: String): Pair<String?, String?> {
        val list = uiState.value.filteredSongs.ifEmpty { _allSongs.value }
        val idx = list.indexOfFirst { it.id == songId }
        if (idx == -1) return null to null
        val prev = list.getOrNull(idx - 1)?.id
        val next = list.getOrNull(idx + 1)?.id
        return prev to next
    }

    private fun filterSongs(
        songs: List<Song>,
        section: SongSection,
        categoryId: String?,
        rawQuery: String,
        favoriteIds: Set<String>
    ): List<Song> {
        val q = rawQuery.trim()
        // When user types a search query, search across the active section (or all if Favorites isn't selected)
        val base = when (section) {
            SongSection.FAVORITES -> songs.filter { it.id in favoriteIds }
            else -> songs.filter { it.section == section.key }
        }
        val catFiltered = if (categoryId != null && section == SongSection.BHAJAN) {
            base.filter { categoryId in it.categoryIds }
        } else {
            base
        }
        if (q.isEmpty()) return catFiltered

        val normalizedDigits = nepaliDigitsToAscii(q)
        val numQuery = normalizedDigits.toIntOrNull()
        val qLower = q.lowercase()

        return catFiltered.filter { song ->
            (numQuery != null && song.number == numQuery) ||
                song.number.toString().contains(normalizedDigits) ||
                song.numberNepali.contains(q) ||
                song.title.contains(q, ignoreCase = true) ||
                (song.englishTitle?.lowercase()?.contains(qLower) == true) ||
                song.lyrics.contains(q, ignoreCase = true)
        }.sortedWith(compareByDescending<Song> { numQuery != null && it.number == numQuery }.thenBy { it.number })
    }

    private fun nepaliDigitsToAscii(input: String): String {
        val map = mapOf(
            '०' to '0', '१' to '1', '२' to '2', '३' to '3', '४' to '4',
            '५' to '5', '६' to '6', '७' to '7', '८' to '8', '९' to '9'
        )
        return buildString(input.length) {
            for (ch in input) append(map[ch] ?: ch)
        }
    }
}
